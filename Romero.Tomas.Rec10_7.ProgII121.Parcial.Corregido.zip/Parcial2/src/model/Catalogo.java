package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Catalogo<T> implements Iterable<T> {

    private List<T> items;

    public Catalogo() {
        this.items = new ArrayList<>();
    }

    public void agregar(T item) {
        checkNull(item);
        items.add(item);
    }

    public T obtenerPorIndice(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }
    
    public void eliminarPorIndice(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }

    public boolean eliminar(T pelicula) {
        checkNull(pelicula);
        boolean toReturn = false;
        Iterator<T> i = items.iterator();
        while (i.hasNext()) {
            if (i.next().equals(pelicula)) {
                i.remove();
                toReturn = true;
            }
        }
        return toReturn;
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();

        for (T item : items) {
            if (criterio.test(item)) {
                listaFiltrada.add(item);
            }
        }
        return listaFiltrada;
    }
    
    public void ordenar() {
        if (items != null && !items.isEmpty() && items.get(0) instanceof Comparable) {
            items.sort(null); 
        }
    }

    public void ordenar(Comparator<? super T> comparador) {
        Iterator<T> it = this.iterator(comparador);
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }

    public void guardarEnArchivo(String path) {
        serializarPeliculas((List<? extends Pelicula>)items, path);
    }
    
    public void serializarPeliculas(List<? extends Pelicula> lista, String path){
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            
            salida.writeObject(lista);

        } catch (IOException ex) {
            System.out.println("Problema al serializar.");
        }
    }

  
    public void cargarDesdeArchivo(String path){
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))){
            items = (List<T>) entrada.readObject();
            
        }catch(ClassNotFoundException | IOException ex){
            System.out.println(ex.getMessage());
        }

    }

    public void guardarEnCSV(String path) {
        try(BufferedWriter br = new BufferedWriter(new FileWriter(path))){
            
            if (items.isEmpty() || !(items.get(0) instanceof Pelicula)) {
            System.out.println("Los elementos no son del tipo Pelicula");
            return;
        }

        br.write(Pelicula.toCSVHeader());
        for (T item : items) {
            Pelicula p = (Pelicula) item;
            br.write(p.toCSV());
        }
            
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public int tamanio() {
        return items.size();
    }

  
    
    public  List<Pelicula> cargarDesdeCSV(String path){
        List<Pelicula> toReturn = new ArrayList<>();
        
        File f = new File(path);

        try (BufferedReader bf = new BufferedReader(new FileReader(f))) {

            String linea;
            bf.readLine();

            while ((linea = bf.readLine()) != null) {
                toReturn.add(Pelicula.fromCSV(linea));
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        return toReturn;
    }

    @Override
    public Iterator<T> iterator() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return items.iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        List<T> copia = new ArrayList<>(items);
        copia.sort(comparador);
        return copia.iterator();
    }
    
    private void validarIndice(int indice) {
        if (indice < 0 || indice > tamanio() - 1) {
            throw new IllegalArgumentException("Indice inválido");
        }
    }

    private void checkNull(T pelicula) {
        if (pelicula == null) {
            throw new NullPointerException("La pelicula es nula");
        }
    }
}
