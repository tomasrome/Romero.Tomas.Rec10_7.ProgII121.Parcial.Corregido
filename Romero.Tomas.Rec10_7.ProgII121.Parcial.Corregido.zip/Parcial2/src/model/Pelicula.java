
package model;

import java.io.Serializable;


public class Pelicula implements Serializable, CSVSerializable, Comparable<Pelicula>{
    
    private final int id;
    private final String titulo;
    private final String director;
    private final Genero genero;

    public Pelicula(int id, String titulo, String director, Genero genero) {
        this.id = id;
        this.titulo = titulo;
        this.director = director;
        this.genero = genero;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public Genero getGenero(){
        return genero;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Titulo: " + titulo + ", Director: " + director + ", Genero: " + genero;
    }

    @Override
    public int compareTo(Pelicula p) {
        return Integer.compare(id, p.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + director + "," + genero; 
    }
    
    public static String toCSVHeader(){
        return "id,titulo,director,genero\n";
    }


    public static Pelicula fromCSV(String peliculaCSV) {
        Pelicula toReturn = null;
        String[]values = peliculaCSV.split(",");
        
        if(values.length == 4){
            int id = Integer.parseInt(values[0]);
            String titulo = values[1];
            String director = values[2];
            Genero genero = Genero.valueOf(values[3]);
            toReturn = new Pelicula(id, titulo,director, genero);
        }  
        return toReturn;
    }
            
}
